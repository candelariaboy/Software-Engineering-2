## [7.26.28](https://github.com/sweetalert2/sweetalert2/compare/v7.26.27...v7.26.28) (2018-09-07)


### Bug Fixes

* **release:** purge jsdelivr before switching to master ([#1215](https://github.com/sweetalert2/sweetalert2/issues/1215)) ([4b5c55d](https://github.com/sweetalert2/sweetalert2/commit/4b5c55d))

## [7.26.27](https://github.com/sweetalert2/sweetalert2/compare/v7.26.26...v7.26.27) (2018-09-07)


### Bug Fixes

* **release:** purge jsdelivr cache after releasing a new version ([#1214](https://github.com/sweetalert2/sweetalert2/issues/1214)) ([6229c1f](https://github.com/sweetalert2/sweetalert2/commit/6229c1f))

## [7.26.26](https://github.com/sweetalert2/sweetalert2/compare/v7.26.25...v7.26.26) (2018-09-06)


### Bug Fixes

* **release:** remove --unshallow from fetch ([8f18115](https://github.com/sweetalert2/sweetalert2/commit/8f18115))

## [7.26.25](https://github.com/sweetalert2/sweetalert2/compare/v7.26.24...v7.26.25) (2018-09-06)


### Bug Fixes

* **release:** fix cherry-picking the latest commit to master ([d2da2e1](https://github.com/sweetalert2/sweetalert2/commit/d2da2e1))

## [7.26.24](https://github.com/sweetalert2/sweetalert2/compare/v7.26.23...v7.26.24) (2018-09-06)


### Bug Fixes

* clear changelog and trigger new release ([b652257](https://github.com/sweetalert2/sweetalert2/commit/b652257))
